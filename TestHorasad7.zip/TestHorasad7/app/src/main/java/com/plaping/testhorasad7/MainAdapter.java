package com.plaping.testhorasad7;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

/**
 * Created by Jaturaiwt Jantarasriwongs.
 * Plaping Studio Co., Ltd.
 */
public class MainAdapter extends BaseAdapter {

    private ArrayList<ArrayList<String>> horoData;
    private Context context;

    public MainAdapter(Context context) {
        this.context = context;
    }

    public void setData(ArrayList<ArrayList<String>> horoData) {
        this.horoData = horoData;
    }

    @Override
    public int getCount() {
        return horoData.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        ItemList itemList = new ItemList(this.context);
        itemList.fillData(this.horoData.get(i));

        return itemList;
    }
}
