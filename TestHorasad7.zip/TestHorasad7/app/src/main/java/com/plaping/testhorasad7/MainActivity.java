package com.plaping.testhorasad7;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Jaturaiwt Jantarasriwongs.
 * Plaping Studio Co., Ltd.
 */
public class MainActivity extends Activity {

    private ListView listView;
    private Button btnAdd;
    private Button btnRemove;

    private ArrayList<ArrayList<String>> horoData;
    private MainAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.listView = (ListView) this.findViewById(R.id.listView);


        this.horoData = getHoroData(2);
        adapter = new MainAdapter(this);
        adapter.setData(horoData);
        this.listView.setAdapter(adapter);

        this.btnAdd = (Button) this.findViewById(R.id.btnAdd);
        this.btnRemove = (Button) this.findViewById(R.id.btnRemove);

        this.btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                horoData = getHoroData(horoData.size() + 1);
                adapter.setData(horoData);
                adapter.notifyDataSetChanged();
            }
        });

        this.btnRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                horoData = getHoroData(horoData.size() - 1);
                adapter.setData(horoData);
                adapter.notifyDataSetChanged();
            }
        });
    }


    private ArrayList<ArrayList<String>> getHoroData(int line){
        ArrayList<ArrayList<String>> horoData = new ArrayList<>();
        for (int i = 0 ; i < line ; i++){
            ArrayList<String> numbers = new ArrayList<>();
            numbers.add("๑");
            numbers.add("๑");
            numbers.add("๑");
            numbers.add("๑");
            numbers.add("๑");
            numbers.add("๑");
            numbers.add("๑");
            horoData.add(numbers);
        }

        return horoData;
    }


}
