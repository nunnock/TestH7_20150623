package com.plaping.testhorasad7;

import android.content.Context;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.util.ArrayList;

/**
 * Created by Jaturaiwt Jantarasriwongs.
 * Plaping Studio Co., Ltd.
 */
public class ItemList extends RelativeLayout {

    private LinearLayout lnItemList;

    public ItemList(Context context) {
        super(context);
        init();
    }

    public ItemList(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ItemList(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init(){
        LayoutInflater inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.item_list, this, true);

        this.lnItemList = (LinearLayout) this.findViewById(R.id.lnItemList);
    }

    public void fillData(ArrayList<String> data){
        for(int i = 0 ; i < data.size() ; i++){
            if(i != 2) {
                ItemNumber itemNumber = new ItemNumber(getContext());
                itemNumber.fillData(data.get(i).toString());
                this.lnItemList.addView(itemNumber);
            }else{
                ItemNumberLine itemNumberLine = new ItemNumberLine(getContext());
                itemNumberLine.fillData(data.get(i).toString());
                this.lnItemList.addView(itemNumberLine);
            }
        }
    }

}
