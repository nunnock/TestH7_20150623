package com.plaping.testhorasad7;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Created by Jaturaiwt Jantarasriwongs.
 * Plaping Studio Co., Ltd.
 */
public class ItemNumberLine extends RelativeLayout {

    private TextView tvNumber;

    public ItemNumberLine(Context context) {
        super(context);
        init();
    }

    public ItemNumberLine(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ItemNumberLine(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init(){
        LayoutInflater inflater = (LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        inflater.inflate(R.layout.item_number_line, this, true);
        this.tvNumber = (TextView) this.findViewById(R.id.tvNumber);

    }

    public void fillData(String number){
        this.tvNumber.setText(number);
    }
}
